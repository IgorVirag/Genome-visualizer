#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun May  1 19:14:39 2022

@author: igorvirag
"""


def Unos_nukleobaza():
    
    Nukleobaze_lista = list()
    Stop = False
     
    while Stop==False:
        Nukleobaze_ručno = input("Enter nuclebase labels: ")
        Nukleobaze_ručno = Nukleobaze_ručno.upper()
        Nukleobaze_ručno = Nukleobaze_ručno.replace(" ","")
        Nukleobaze_ručno = list(Nukleobaze_ručno)
        
        for a in Nukleobaze_ručno:
            if a == "A" or a=="T" or a=="C" or a=="G":
                pass
    
            elif a=="Q":
                Stop = bool(1)
                print()
                print("Nucleobase entry is completed.")
                print()
    
                break
            
            else:
                print()
                print(f"Entry '{a}' on position '{Nukleobaze_ručno.index(a)+1}' in '{Nukleobaze_ručno}' is incorrect!")
                print()
                while True:
                    zamjena = input("Replace incorrect entry: ")
                    zamjena = zamjena.upper()
                    if zamjena == 'A' or zamjena == 'T' or zamjena == 'C' or zamjena == 'G':
                        break
                    else:
                        print()
                        print(f"\033[1;31mYou made a mistake again... \033[0m you entered '{zamjena}' instead A, T, C or G.")
                        print()
                        print(f"Entry '{a}' on position '{Nukleobaze_ručno.index(a)+1}' in '{Nukleobaze_ručno}' is incorrect!")
                        print()
                        
    
                Index_krive_nb = Nukleobaze_ručno.index(a)
                Nukleobaze_ručno[Index_krive_nb] = zamjena
            
        for b in Nukleobaze_ručno:
            Nukleobaze_lista.append(b)
    
    return Nukleobaze_lista





def Nasumicna_mutacija(Nukleobaze_lista):
    import random
    broj_mutacija = 1
    rand_index = random.randint(0,len(Nukleobaze_lista)-1)
    rand_nb = random.choice(['A','T','C','G'])
    Izvrsena_mutacija = False
    
    while Izvrsena_mutacija == False:
        if Nukleobaze_lista[rand_index] == rand_nb:
            rand_nb = random.choice(['A','T','C','G'])
        else:
            Izvrsena_mutacija = bool(1)
    print()     
    print("Mutation completed!")
    print()
    Nukleobaze_lista_mutacija= Nukleobaze_lista[:]
    Nukleobaze_lista_mutacija[rand_index]=rand_nb
    return Nukleobaze_lista_mutacija,rand_index





def Izvrsi_mutaciju(dali_da_mutiramo,Nukleobaze_lista):
    Nukleobaze_mutacija_desna_str_lista = list()
    Neuklobaze_desna_str_lista = list()


    if dali_da_mutiramo == "YES":
        
        Mutacija = Nasumicna_mutacija(Nukleobaze_lista) # pozivam definiciju mutacije i spremam rezultate
        Nukleobaze_mutacija, index_promjene = Mutacija # razdvajam tuple na nukleo baze gdje postoji mutacija i index gdje se dogodila mutacija
    
    
        for c in Nukleobaze_mutacija:
            if c == "A":
                Nukleobaze_mutacija_desna_str_lista.append('T')
            elif c=="T":
                Nukleobaze_mutacija_desna_str_lista.append('A')
            elif c=="C":
                Nukleobaze_mutacija_desna_str_lista.append('G')
            elif c=="G":
                Nukleobaze_mutacija_desna_str_lista.append('C')
                
        return Nukleobaze_mutacija,Nukleobaze_mutacija_desna_str_lista,index_promjene,Nukleobaze_lista[index_promjene]
    


    elif dali_da_mutiramo == "NO":

        
        for d in Nukleobaze_lista:
            if d == "A":
                Neuklobaze_desna_str_lista.append('T')
            elif d=="T":
                Neuklobaze_desna_str_lista.append('A')
            elif d=="C":
                Neuklobaze_desna_str_lista.append('G')
            elif d=="G":
                Neuklobaze_desna_str_lista.append('C')
                
        return Nukleobaze_lista,Neuklobaze_desna_str_lista
    

    
def Plot_mutirane(df_mutacija):
    try:
        lijeva,desna,pozicija,vrijednost_prije = df_mutacija
        index = list(range(0,len(lijeva)))
        print("             GENOME")
        print()
    
        for e,f,g in zip(lijeva,desna,index):
            if g != pozicija:
                print("Nucleobases: " ,e+"-"+f," no mutation")
            elif g == pozicija and vrijednost_prije == "A":
                print("Nucleobases: ",'\033[1;31m'+e+"-"+f+'\033[0m',"\033[1;31m MUTATION \033[0m  -----> Nucleobase value before mutation:", vrijednost_prije+"-T")
            elif g == pozicija and vrijednost_prije == "T":
                print("Nucleobases: ",'\033[1;31m'+e+"-"+f+'\033[0m',"\033[1;31m MUTATION \033[0m  -----> Nucleobase value before mutation:", vrijednost_prije+"-A")
            elif g == pozicija and vrijednost_prije == "C":
                print("Nucleobases: ",'\033[1;31m'+e+"-"+f+'\033[0m',"\033[1;31m MUTATION \033[0m  -----> Nucleobase value before mutation:", vrijednost_prije+"-G")
            elif g == pozicija and vrijednost_prije == "G":
                print("Nucleobases: ",'\033[1;31m'+e+"-"+f+'\033[0m',"\033[1;31m MUTATION \033[0m  -----> Nucleobase value before mutation:", vrijednost_prije+"-C")
                
    except ValueError:
        pass
    

def Plot_nemutirane(df_mutacija):
    try:
        lijeva,desna = df_mutacija
        print("            GENOME")
        for h,l in zip(lijeva,desna):
            print("Nucleobases: ",h+"-"+l)
    
    except ValueError:
        pass